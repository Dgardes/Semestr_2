# Лабораторна робота №1 — JavaScript практика

**Варіант:** [6]

## Структура проєкту

- `src/task-1.js` — Деструктуризація та spread/rest
- `src/task-2.js` — Методи масивів
- `src/task-3.js` — Класи та наслідування
- `src/task-4.js` — async/await та Promises
- `src/task-5/` — ES6 модулі

## Запуск

1. Відкрийте проєкт у VS Code
2. Запустіть `index.html` через Live Server (правий клік → Open with Live Server)
3. Відкрийте консоль розробника (F12) для перегляду результатів